# 09. Open decisions and prerequisites

Only items that materially change implementation are listed. Each prerequisite is a bounded feasibility experiment scheduled in M1 ([06 §2](06-migration-plan.md#2-stages-and-dependencies)); none was executed in this design task.

## 1. Prerequisites

| ID | Experiment | Pass criterion | Fail consequence | Blocks |
|---|---|---|---|---|
| PR-1 | A skeleton Rust Engine runs on Windows 11 without administrator rights in the `DeszoEngine` profile with the grants of 02 §7: SQLite WAL in its Store directory, typed pipe transport to a test Host, normal exit and kill-on-close | It runs; and, with evidence files: it cannot read or write the Host and gateway directories or ungranted folders; it cannot open the Host or Shell process; its child processes are contained; a contained process cannot open another contained process or duplicate a Host-held handle | Revisit the affected control in 03 before M4 | M4, M5 |
| PR-2 | Each provider CLI (codex, claude, agy) runs in a `DeszoProvider` profile with grants to one workspace, its own configuration directory and network access, signs in with the existing account state and completes a trivial prompt with one file edit | Works for the provider, with the same invocation the Engine builds today | OD-1 decides for that provider | M7 for repair runs of that provider |
| PR-3 | `cargo build` and `cargo test` of the workspace run offline in `DeszoBuild` and `DeszoVerify` with only the snapshot, toolchain, vendor and scratch directories granted | Builds and tests pass; the MSVC linker and SDK are reachable read-only; a build script cannot write outside its output directory | OD-8 (self-contained target) or a design change for build isolation | M7, M8 |
| PR-4 | Two production builds of the Engine in different directories with the flags of 04 §6.1 | Every package file byte-identical | OD-8 fallback (same-path rebuild) | M8 |
| PR-5 | Every Host spawn (Shell, Engine, provider runs, jobs) uses an explicit handle list; rerun with distinct payloads written after the children start | Each child reads only its own channel; server ends are not inheritable | Fix the spawn path before M4 exits | M4 |
| PR-6 | Host-side Git object identity recomputation (04 §3.1) against Git on vectors including line-ending cases, executable mode, empty trees and the object format in use | Identical object ids for every vector | Fix before M7 | M7 |
| PR-7 | Rust Store layer on a copy of a real profile: open, read every table, re-hash every object with the Rust canonicalizer; then a Node Engine reads a Rust-written copy | All digests equal; Node opens the copy without migration | Fix canonical or Store layer before M5 | M3 exit, M5 |

## 2. Owner decisions

| ID | Decision | Options | Recommendation | Affects |
|---|---|---|---|---|
| OD-1 | Containment of provider runs | (a) all managed provider runs contained, which adds per-workspace grants on the user's project folders; (b) repair-related runs contained, ordinary runs optionally unconfined, in which case the Host keeps P5 admission closed (03 §7); (c) a provider that fails PR-2 is unavailable for repair runs | (a), with (c) for a failing provider | 03, 04 §2.1, M4, M7 |
| OD-2 | Cutover enrollment | The Owner installs one root enrollment for the first Rust baseline; Node-era P5/P6 records stay history only; slots with any recorded claim are imported as consumed | Accept | 05 §4, 06 §5 |
| OD-3 | Platform order | Windows first; Linux and macOS each gated on their own prerequisite run (03 §6) | Accept | 03 §6, M1 |
| OD-4 | Manual selection of an earlier committed Engine | (a) none, as today; (b) an Owner-authenticated Host command that selects an earlier committed build through the normal G0 path, never automatic | (b) | 02 §8 |
| OD-5 | Legacy Local Control Host (ADR-0006) and ADR-0007 Judge attention | Retire both; archive the Control Host database; the autonomy routes answer unavailable | Retire, unless an installation depends on them | 05 §6, 06 §3 |
| OD-6 | External client credential | (a) Owner-run clients keep using the Owner Token from the Host descriptor (no change); (b) add a scoped external-client token | (a) now; (b) as a later option | 05 §7 |
| OD-7 | Interim release before Rust Engine parity | (a) none; (b) a release with a contained Node Engine under the new Host, if PR-1 is also shown for Node ESM | (a) unless the release date matters more than the extra Node containment work | 06 §4, 08 §4 |
| OD-8 | Engine build target and reproducibility fallback | (a) `x86_64-pc-windows-msvc` with the MSVC linker and SDK in the toolchain identity; (b) a self-contained target for the Engine only; and if PR-4 fails, same-path rebuild recorded in the receipt | (a) if PR-3 and PR-4 pass, else (b) | 04 §6 |

## 3. Technical questions resolved during implementation, not by the Owner

- Per-run workspace grants: a profile per run or capability identifiers per run (PR-1, PR-2).
- Dependency cache layout for verification jobs (04 §5).
- Frame size and chunking constants (05 §5).
- Exact admission attempt budget, taken from the enrolled budgets.
- The profile for network-using Engine operations, such as the Owner-requested branch publication (`runtime/core/p5GitCandidate.mjs`): a custody job with a network grant and the user's Git credential configuration, settled together with PR-2.
