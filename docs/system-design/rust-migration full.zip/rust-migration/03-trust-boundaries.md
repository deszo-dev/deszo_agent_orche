# 03. Trust boundaries, principals and enforcement

## 1. What enforces the boundary

Rust is not a sandbox. A repairable Rust executable can perform any filesystem, network and process operation its OS token allows. The following are **not** enforcement mechanisms in this design and are used only for code organization: private modules, `pub(crate)`, crate boundaries, ownership and borrowing, memory safety, static linking, obfuscated identifiers.

The enforcement mechanisms are:

| Mechanism | What it enforces | Platform status |
|---|---|---|
| **OS containment profile** for every process that can run candidate- or provider-controlled code (AppContainer on Windows) | No access to Host files, Host memory, the Owner Token, ungranted folders or loopback listeners | Windows: demonstrated for a contained child against an uncontained parent (Decision C §5.1); prerequisites PR-1, PR-2 cover the rest. Linux and macOS: design only (§6) |
| **Filesystem ACLs** on Host state | Integrity and confidentiality of enrollment, admission journal, receipts, Owner Token | Windows: per-SID grants; ungranted access denied by AppContainer (demonstrated) |
| **Inherited anonymous pipes with explicit handle lists** | Channel identity equals principal identity; no capability secret | Windows: shown for contained children (Decision C §5.3); clean rerun is PR-5 |
| **Job objects with kill-on-close** | Process-tree lifetime and termination proof | Windows: exists in Host and custody |
| **Host-side computation of every admission fact** | Acceptance cannot be asserted by the Engine | Design (04) |

The previous architecture's failure was that all of these were absent between the Engine and the Host: one OS user, one loopback capability, and acceptance evidence in a Store the Engine writes (01 §4).

## 2. Principals

| ID | Principal | Process and token | Trust |
|---|---|---|---|
| O | Owner and trusted UI | Owner's own processes, Shell WebView | Root of authority |
| H | Lifecycle Host with Admission | `deszo-host.exe`, user token | Trusted |
| E | Repairable Engine | `deszo-engine.exe`, AppContainer `DeszoEngine` | Repairable, untrusted for authority |
| D | Developer-controlled candidate | candidate source; its code runs in V and B jobs, and later as E | Untrusted |
| V | Gate verification execution | AppContainer `DeszoVerify` | Untrusted (runs candidate tests) |
| B | Build execution | AppContainer `DeszoBuild` | Untrusted (runs `build.rs`, proc macros) |
| J | Judge and provider execution | provider CLI in AppContainer `DeszoProvider` | Untrusted output, semantically trusted only as the enrolled Judge's opinion |
| X | External CLI processes run by the Owner (MCP bridge, scripts) | user token | Owner's own processes (A4 below) |

## 3. Capability matrix

```mermaid
flowchart LR
    subgraph T["Trusted: user token"]
        H["Host<br/>lifecycle, switch, custody,<br/>gateway, Admission"]
        HS[("Host state<br/>enrollment, slots, admission journal,<br/>receipts, active.json, Owner Token")]
        SH["Shell + UI"]
    end
    subgraph C["Contained profiles"]
        E["Engine (DeszoEngine)"]
        ES[("Engine Store, workdirs")]
        P["Provider runs (DeszoProvider)"]
        VB["Verify and build jobs<br/>(DeszoVerify, DeszoBuild)"]
    end
    H --- HS
    SH -- "Owner Token over loopback" --> H
    E -- "typed requests only:<br/>status, custody (own records),<br/>Repair requests, drain ack" --> H
    H -- "forwarded API, receipts,<br/>drain requests" --> E
    E --- ES
    H -- "launch and capture" --> P
    H -- "launch and capture" --> VB
    E -. "no grant" .-> HS
    P -. "no grant" .-> HS
    VB -. "no grant" .-> HS
```

Solid lines are the only channels. Dotted lines are denied by the containment profile. Authority to accept, build and switch exists only inside the trusted box.

| Principal | Owned data | Reads | Writes | Credentials | IPC operations | Filesystem | Launch | P5 acceptance | P6 build | G0 switch |
|---|---|---|---|---|---|---|---|---|---|---|
| O / Shell | UI state | API via gateway | API via gateway | Owner Token (from Host pipe) | gateway HTTP | user | none from Deszo | none (one-time enrollment install only) | none | none (OD-4 manual selection only) |
| H | installation, `active.json`, journals, enrollment, slot registry, admission journal, receipts, Owner Token | everything it needs | its own state; grants | Owner Token, per-run Judge and controller credentials it issues | all channels | user | everything, into containment | **decides** | **runs and records** | **decides and executes** |
| E | ordinary Store, workdirs | own Store, release files, granted workspaces | own Store, workdirs | none with Host authority; per-run scoped tokens it issues to its own API callers | E channel: §4 | `store/`, `workdirs/`, granted workspaces; read selected `versions/` | none outside its container; provider launches only through custody | submit candidate, read status | none | none (drain acknowledgement only) |
| D (as source) | none | none | none | none | none | none | none | none | none | none |
| V | its scratch | candidate snapshot, baseline snapshot, toolchain, vendor | scratch | none | result pipe to H | granted job directories only | children inherit containment | none (raw results only) | none | none |
| B | its scratch | candidate snapshot, toolchain, vendor | output dir | none | result pipe to H | granted job directories only | children inherit containment | none | output bytes only | none |
| J | none | its dossier (stdin), its config dir | its config dir | provider account session in its config dir | none; stdout and stderr spooled by H | granted per run | children inherit containment | output captured by H | none | none |
| X | none | API | API | token from Host descriptor (05 §7) | gateway HTTP | user | user | none beyond API | none | none |

The key rows: **E has no column with authority**, and the three right-hand columns are owned by H alone.

## 4. The Engine channel

Ordinary capabilities on E's pipe pair (all typed messages in `deszo-protocol`, 05 §5):

- `Ready`, `ReceiptAck` (own generation only), `Status`, `RunningRelease`, `RunningInventory`.
- `Custody::{Reserve, Launch, Status, Read, Ack, Cancel, Stop}`, scoped by the Host to custody records the Engine created in the current Engine lineage. `Attach` does not exist; the Host binds the generation at spawn. Emergency stop of Host-owned jobs (verification, build, acceptance Judge) is not reachable.
- `Repair::{EnrollmentStatus, ClaimSlot, SubmitCandidate, AdmissionStatus, ReportInvalidation}` (04 §2). `ReportInvalidation` can only stop an admission.
- `Lifecycle::{DrainAck, MaintenanceReady}` (own generation only).
- `Api::Response` and `Api::Event` frames answering forwarded requests.

Not on E's channel, by construction (no message type exists): stage, switch, fence, attach, legacy activation, acceptance, build, enrollment change, Owner Token rotation, custody of Host-owned jobs.

## 5. Threat model

Adversaries:

- **A1** repairable code in E (an accepted but faulty or malicious candidate, or a compromised dependency).
- **A2** candidate code in V and B (tests, build scripts, procedural macros).
- **A3** any process started by E, V, B or J.
- **A4** an unconfined process of the Owner's own user (the Owner's own trust domain).
- **A5** a provider CLI or model output steered by untrusted content (prompt injection), including the Judge.

| Adversary | Goal | Control | Residual |
|---|---|---|---|
| A1 | Stage or switch without acceptance | No such message on E's channel; the switch trigger is Host-internal (04 §7) | none known |
| A1 | Forge acceptance evidence | Evidence is created by H from H-produced or H-observed data and stored in H-only files (05 §3) | Engine-supplied incident narrative is data for the Judge, not evidence (§7) |
| A1 | Read the Owner Token or Host memory | E is contained; the token lives in H and the Shell; the descriptor is in an H-only directory | PR-1 must show the denials for these exact paths and processes |
| A1, A3 | Reach Host state through a child | Children inherit the container token | PR-1 must show it; Decision C left it unshown |
| A1 | Widen enrollment, scope, budgets or slots | Root enrollment and slot registry are H state; successor enrollment is derived by H (04 §8) | none known |
| A2 | Escape the build or test job | V and B are contained, offline, time and memory bounded | PR-3 |
| A2 | Fake test results | Exit status and captured output are observed by H; the candidate controls the code under test | Semantic limit (§7) |
| A3 | Inherit privileged handles | Explicit handle list for every Host spawn; server ends non-inheritable | PR-5 |
| A5 | Approve a bad candidate through the Judge | Host builds the dossier from verified evidence and enforces the enrolled Judge profile; containment bounds the damage of a wrong approval (§7) | Semantic limit, accepted as today (P6 final security review S5-7) |
| A4 | Anything the user can do | Out of scope: the Owner's own processes are the trust domain | Recorded. The Owner's own external clients may hold the Owner Token (05 §7) |

## 6. Cross-platform isolation

| Platform | Mechanism for E, V, B, J | Supported | Implemented | Demonstrated | Remaining work |
|---|---|---|---|---|---|
| Windows 10/11 | AppContainer (or LPAC) profiles, per-SID ACL grants, Job objects, explicit handle lists, no loopback for contained processes | target | no | partial (Decision C §5) | PR-1, PR-2, PR-3, PR-5 |
| Linux | Unprivileged user and mount namespaces (bind-mount only granted paths), Landlock for filesystem rules, seccomp for `ptrace`/`process_vm_readv`, `PR_SET_NO_NEW_PRIVS`, cgroup or process-group supervision | design | no | no | Separate spike; Landlock availability depends on the kernel version; `ptrace` scope must deny the Host |
| macOS | Seatbelt profiles (`sandbox_init` or `sandbox-exec`, deprecated but functional) for path rules; App Sandbox entitlements apply to the signed app, not to arbitrary child processes | design | no | no | Highest uncertainty; provider CLIs may not run under a restrictive profile |

The platform adapter is one `sandbox` module in the Host with one function per platform that turns a profile description (granted paths with modes, network yes or no, limits) into a launch. No generic policy engine is built. Linux and macOS are **supported design, not implemented and not demonstrated**; release on them requires their own prerequisite runs.

## 7. Limits that no mechanism removes

- **Semantic verification.** Candidate code is part of every test binary that links it. A candidate can make its own tests exit 0. The Host can establish *which* code was tested, *which* required checks ran, their exit status and output, and that the reproducer failed on the baseline and passed on the candidate; it cannot establish that the code is correct. The Judge reads a Host-built dossier; a model can be wrong or steered (A5).
- **What bounds the damage.** An accepted wrong candidate becomes an Engine with exactly the Engine's contained authority. It cannot change the Host, the Shell, the enrollment, the policy, the slot pool or the Owner Token, and it cannot activate its successor without passing the same Host-run Admission. That is the property the previous architecture lacked: there, an accepted Engine held the switch.
- **Same-user unconfined processes (A4)** can read and write anything the user can. This includes the Host's memory. The design protects against candidate-controlled and provider-controlled processes, not against the Owner's own software.
- **Ordinary provider runs.** If the Owner enables unconfined provider runs (open decision OD-1), those runs have A4 authority. The Host then refuses P5 admission for the installation, because an unconfined provider could write Host state directly (04 §2).
