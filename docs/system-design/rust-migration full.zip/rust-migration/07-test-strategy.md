# 07. Test strategy

## 1. Principles

- Tests are mapped by **contract**, not by file name: existing Node test → the contract it protects → the Rust test that protects the same contract at the right level.
- The Node suite (113 files, 783 top-level cases, more than 1,000 cases with subtests; 995/995 on the G0 snapshot) defines expected behavior. Its passing results say nothing about the Rust implementation.
- No contract is weakened to make the migration look complete. A Rust test that cannot reproduce a recorded behavior is a defect or an explicit, recorded behavior change with its reason.
- Levels: **unit** (crate-internal, `cargo test`), **integration** (Engine against a fake Host, or Host against a skeleton Engine, in-process or with real pipes), **system** (packaged Host, Shell and Engine on a test profile), **genuine E2E** (A → B → C).

## 2. Contract map

| Contract family | Existing Node tests (examples) | Rust level and location |
|---|---|---|
| Workflow contracts, schemas, validation | `contracts.test.mjs`, `integrity.test.mjs`, `context-contracts.test.mjs`, `effort.test.mjs` | Unit in `deszo-workflow`, `deszo-protocol`; fixture cases from `docs/fixtures` |
| Published workflow immutability, drafts, publications | `authoring.test.mjs`, `p34-publication.test.mjs`, `revisions.test.mjs`, `ui-authoring-transport.test.mjs` | Integration in `deszo-engine` (API level); differential (§3) |
| Run pinning and capture | `engine.test.mjs`, `run-scoped-identity.test.mjs`, `workflow-p1-published-and-ordinary.test.mjs` | Integration; differential journals |
| Scheduler, Loop, Map, Task, review Gate | `loops.test.mjs`, `map.test.mjs`, `managed-task.test.mjs`, `pipeline.test.mjs`, `reference.test.mjs`, `task-assessment.test.mjs` | Unit for pure transitions (`m2Transition`, `loopStep`, `routeCase` equivalents); integration with fixture providers |
| Progress-driven continuation, no termination on silence | `workflow-continuation*.test.mjs`, `workflow-p1-*.test.mjs`, `followup.test.mjs` | Integration with time-controlled fixture providers |
| Judge authority and Owner questions | `workflow-judge-policy.test.mjs`, `workflow-judge-runtime.test.mjs`, `workflow-judge-scenarios.test.mjs`, `judge-control.test.mjs`, `judge-recovery.test.mjs` | Unit for decision application; integration for question routing; Host unit tests for acceptance decision parsing |
| P2 Repair | `parent-repair-coordination.test.mjs`, `linked-repair-isolation.test.mjs`, `p2-migration.test.mjs`, `parent-repair-custody-e2e.test.mjs` | Engine integration against a fake Admission |
| Failure outcomes | `failure-outcomes.test.mjs` | Unit |
| Provider adapters | `codex-adapter.test.mjs`, `antigravity*.test.mjs` | Unit on recorded native streams |
| Custody and fencing | `process-custody.test.mjs`, `custody-*.test.mjs`, `p6-g0-custody-e2e.test.mjs` | Host unit (existing Rust tests) and system tests |
| Crash and restart recovery | `engine-startup.test.mjs`, `restart-control.test.mjs`, `p6-g0-recovery.test.mjs`, `p6-g0-c09.test.mjs`, `runner-lock.test.mjs` | Engine integration (Store recovery); Host system tests (G0 recovery) |
| Host switching (G0) | `p6-g0-switch.test.mjs`, `p6-g0-c02-c13.test.mjs`, `p6-g0-m1-commit-order.test.mjs`, `p6-g0-identity.test.mjs`, `p6-g0-admission*.test.mjs`, `rust-host-lifecycle.test.mjs`, `tauri-host-proof-b.test.mjs` | Host system tests, re-pointed to the Host-internal trigger |
| Protected P5 | `protected-self-repair.test.mjs`, `p5-verifier.test.mjs`, `p5-e2e.test.mjs`, `p6-gate-negatives.test.mjs` | Host Admission integration with fixture candidates |
| Workspace isolation and slot pool | `p5-workspace-pool.test.mjs`, `p5-workspace-alias.test.mjs`, `p5-workspace-reserved-run.test.mjs`, `p6-s2d-duplicate-claim.test.mjs` | Host slot-pool unit tests; Engine ordinary-run reservation tests |
| Git source identity | `p5-native-source-identity.test.mjs`, `p5-crlf-identity.test.mjs`, `p5-managed-clone.test.mjs` | Host identity unit tests with object vectors; Engine `deszo-git` integration |
| Candidate scope and trusted build | `p6-builder-boundary.test.mjs`, `p6-build-unit.test.mjs`, `p6-build-integration.test.mjs`, `desktop-build-*.test.mjs` | Host policy unit tests; build-job integration; reproducibility test |
| P6 acceptance and continuation | `p6-successor-identity.test.mjs`, `p6-build-e2e.test.mjs` | Host successor-enrollment unit tests; system test |
| A → B → C and exhaustion | `p6-genuine-e2e.test.mjs` | Genuine E2E (§6) |
| API permissions and Owner Token | `amd19-authorization.test.mjs`, `controller-tools.test.mjs`, `bridge.test.mjs`, `run-observer.test.mjs`, `supervision.test.mjs` | Gateway integration; MCP contract tests |
| Legacy Control Host and ADR-0006 | `adr6-*.test.mjs`, `control-host*.test.mjs` | Retired with OD-5; replaced by one test that the autonomy routes answer unavailable |
| Test infrastructure | `test-roots.test.mjs`, `release.test.mjs` | `xtask` and harness tests |

M0 produces the complete table with every file and the contract IDs it covers. A file whose contract has no Rust row blocks M10.

## 3. Differential verification

The same scenario runs through the Node Engine and the Rust Engine on two copies of one fixture profile, with the same fixture provider responses (`runtime/tests/fixture-cli.mjs` scenarios, recorded and replayed by `deszo-testkit`). Compared after normalizing identifiers, timestamps and process ids:

- persistent state: rows of the run, attempt, journal, receipt and publication tables; artifact digests;
- journal event sequences and payloads;
- API responses, status codes and ETags for the route inventory;
- lifecycle transitions on the Host side;
- refusal codes for invalid requests.

Implementation details that do not form a contract (internal ordering of unrelated events in one commit, log text, timing) are excluded by an explicit normalization list. Every exclusion is listed with its reason, so the comparison does not silently widen.

## 4. Golden vectors

- Canonical JSON: every object in the M0 profile copy, plus generated cases for key ordering beyond the Basic Multilingual Plane and number formatting (05 §2.1).
- Git object identity: commits, trees and blobs for both object formats in use, including the line-ending cases from the P5 CRLF tests.
- Migration digests: the 22 scripts and their `schema_migrations` rows.
- Provider streams: recorded native output for each provider and output contract.

## 5. Security and refusal tests

These are regression tests of the boundary, written as assertions that something is refused or absent. They do not attempt to obtain credentials or reproduce earlier bypasses; they check that the design's controls hold.

| Property | Test |
|---|---|
| The Engine channel has no privileged verb | The protocol crate's Engine-to-Host enum has no stage, switch, fence, attach, acceptance or build variant (compile-time list test); the Host refuses any unknown frame kind |
| No switch without acceptance | The Host-internal switch trigger is unreachable without an `AcceptanceRecord/1` and a `BuildReceipt/2` for the exact package; the G0 tests assert that staging and switching start only from Admission |
| Engine reports can only narrow | `ReportInvalidation` stops an admission; no Engine message moves an admission forward |
| Protected paths | Each rule of 04 §3.2 has a refusing fixture candidate |
| Required checks and reproducer | A candidate whose reproducer passes on the baseline, or whose required check fails, is refused (re-expressed Gate negatives) |
| Identity | A snapshot with a mismatched object id or a missing object is refused |
| Slot pool | Duplicate claim, exhausted pool and claimed-slot reuse are refused before any build |
| Owner Token placement | The token does not appear in the Engine's bootstrap, environment, pipe traffic or granted directories (asserted on what the Host sends and grants) |
| Containment grants | The Engine's container profile is granted exactly the directories listed in 02 §7; the Host directory is not among them (asserted on the profile the Host builds) |
| Containment enforcement | The PR-1, PR-3 and PR-5 evidence scenarios, once passed in M1, become packaged system tests that run on every release candidate |
| Release manifests | A manifest declaring the `test-seams` feature is refused by the Host |

## 6. Genuine end-to-end

- **A → B → C:** a packaged installation with three slots; two Parent incidents; each Repair produces a candidate in its slot; Admission accepts each; the Host builds, stages and commits B, then C; no Owner request other than the incident starts and reads is made between the root enrollment and C's verification (the existing Owner-action window trace of `p6-genuine-e2e.test.mjs` is kept); no Git push occurs.
- **Exhaustion:** the same with N slots for N Repairs; the last claim is refused before any build.
- **Refusal paths:** one run each where Admission refuses at policy, verification and the acceptance Judge, with the Parent continuing per its captured retry rule.
- Developer, Judge and Parent worker responses are fixture providers, as today; that is stated in the evidence. A real-provider rehearsal is an Owner-run step because it consumes quota.

## 7. Tiers and cost

- `cargo test --workspace` for unit tests on every change.
- Integration tests in a separate `cargo test --test` set, with real pipes.
- System and genuine E2E tests in `xtask` against packaged builds, holding the existing test gate (one gated run at a time, `scripts/run-tests.mjs` rule kept).
- The full regression before a release freeze. Its duration should drop from about three hours (Node G0 regression) because Rust tests run without per-file Node startup, but packaged E2E time is dominated by real process starts and builds; Cargo builds inside verification jobs add minutes per admission (08 §4).
