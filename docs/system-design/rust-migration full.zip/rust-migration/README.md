# Rust backend migration: system design (DESZO-RUST-MIGRATION-SD)

- **Date:** 2026-11-06
- **Status:** design only. No production code, Host, database, API or release was changed; no security probe was run. Nothing is committed.
- **Proposed ADR:** [ADR-0012](../../adr/0012-rust-first-backend-and-engine-lifecycle.md) (Proposed).
- **Proposed verdict:** `DESZO-RUST-MIGRATION-SD ACCEPTED WITH OPEN PREREQUISITES`, pending the independent reviews (§3). The prerequisites, their pass criteria and the stages they block are in [09 §1](09-open-decisions.md#1-prerequisites).

## 1. Summary

Two Rust backend processes: a trusted **Lifecycle Host** that also contains a small **Admission** component (P5 acceptance, P6 build, slot pool), and a repairable **Engine** that runs inside an OS containment profile and holds no privileged verb. The Tauri WebView UI is the only JS/TS runtime. A separate Control Process was evaluated and rejected because it would add a process, a protocol and a reconciliation matrix without adding an OS boundary. The demonstrated direct-switch problem is closed structurally: the Engine's channel has no stage or switch message, and the only switch trigger is a Host record created from evidence the Host produced itself. The design's security depends on containment prerequisites that have not been run.

## 2. Documents

| Document | Content |
|---|---|
| [01-current-architecture.md](01-current-architecture.md) | Process topology, module inventory with Rust destinations, Node-specific mechanisms, evidence classification |
| [02-target-architecture.md](02-target-architecture.md) | Processes, bounded Host responsibilities, Engine responsibilities, Cargo workspace, package, layout, crash and recovery |
| [03-trust-boundaries.md](03-trust-boundaries.md) | Enforcement mechanisms, principals, capability matrix, Engine channel, threat model, platforms, limits |
| [04-self-repair.md](04-self-repair.md) | P5 Admission, Judge placement, verification, Cargo pipeline and build-time risks, receipts, switch, A → B → C |
| [05-store-and-api.md](05-store-and-api.md) | Store compatibility, protected store, data preservation, Host-Engine protocol, gateway, Owner Token |
| [06-migration-plan.md](06-migration-plan.md) | Stages and dependencies, compatibility matrix, coexistence restrictions, cutover and rollback |
| [07-test-strategy.md](07-test-strategy.md) | Contract map, differential verification, golden vectors, refusal tests, genuine E2E |
| [08-alternatives-and-tradeoffs.md](08-alternatives-and-tradeoffs.md) | Options A, B, C and A-S; Node versus Rust; engineering cost and critical path |
| [09-open-decisions.md](09-open-decisions.md) | Prerequisites PR-1 to PR-7 and Owner decisions OD-1 to OD-8 |
| [10-implementation-roadmap.md](10-implementation-roadmap.md) | Milestones R0-R9 with acceptance criteria |
| [11-consistency-review.md](11-consistency-review.md) | Cross-document review, findings and fixes, unresolved decisions |

Diagrams: current architecture (01 §1), target architecture (02 §2), crash and recovery (02 §8), trust boundaries (03 §3), Self-Repair pipeline (04 §1), build and attestation (04 §7), A → B → C (04 §8), Store ownership (05 §3), migration dependencies (06 §2).

## 3. Design acceptance checklist

| Criterion | Status | Where |
|---|---|---|
| All backend JavaScript responsibilities have a Rust destination | Met | 01 §2, 06 §3 |
| Tauri UI is the only final JS/TS runtime component | Met (frontend build tools only) | 02 §2, 06 §6 |
| Current subsystem inventory is sufficiently complete | Met; M0 completes the per-file contract map | 01 §2, 07 §2 |
| Two-process architecture genuinely evaluated | Met | 08 §2 |
| Separate Control Process justified or rejected on evidence | Rejected, with reconsideration triggers | 08 §2 |
| Host's trusted responsibilities explicit and bounded | Met | 02 §3 |
| Engine remains repairable | Met | 02 §4, 04 §8 |
| Trusted acceptance cannot be forged by the Engine | Met in design; enforcement depends on PR-1 | 04, 05 §3 |
| Host cannot be switched by an unauthorized Engine | Met in design (no verb) | 03 §4, 07 §5 |
| Rust build-time candidate execution is contained | Met in design; PR-3 | 04 §6.3 |
| P5 Gate and Judge authority remain intact | Met; semantic limit stated | 04 §4-5 |
| P6 build provenance preserved | Met in design; PR-4 | 04 §6-7 |
| Genuine autonomous A → B → C architecturally supported | Met | 04 §8 |
| Workspace-pool constraints remain enforceable | Met in design; per-run grants depend on PR-1, PR-2 | 04 §2, 04 §8 |
| Existing workflow and Run history can be preserved | Met in design; PR-7 | 05 §2, 05 §4 |
| Owner Token authority and confidentiality addressed | Met in design; PR-1 | 05 §7 |
| API and UI migration covered | Met | 05 §6, 06 §3 |
| Rust test migration specified | Met | 07 |
| Cross-platform implications explicit | Met; Linux and macOS not implemented | 03 §6, OD-3 |
| Migration can proceed in testable stages | Met | 06 §2, 10 |
| Major risks and costs recorded | Met | 08 §5, 11 §3 |
| Independent reviews complete | **Not met**: not run in this pass | 11 §4 |
| No unresolved security contradiction hidden behind a generic assumption | Met by the consistency review; containment is a stated blocking prerequisite, not an assumption | 11 §3 |
