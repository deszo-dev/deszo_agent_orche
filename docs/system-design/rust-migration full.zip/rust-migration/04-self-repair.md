# 04. Rust Self-Repair: P5 acceptance, P6 build and autonomous activation

This document places every Self-Repair step on a principal. The rule from 02 §1 applies throughout: a step that decides authority runs in the Host; a step that executes candidate code runs in a contained job; the Engine orchestrates the workflow and asks.

## 1. Pipeline and placement

```mermaid
flowchart TB
    I["Incident in a Parent Run<br/>(Engine)"] --> PJ["Parent Judge: request_repair<br/>(Engine, workflow node)"]
    PJ --> CS["ClaimSlot<br/>(Host: single-use slot from the enrolled pool)"]
    CS --> DEV["Developer writes a Rust patch in the slot<br/>(provider job, slot grant only)"]
    DEV --> SUB["SubmitCandidate: slot, commit id<br/>(Engine request)"]
    SUB --> SNAP["Snapshot and identity<br/>(Host: export job, Host recomputes digests)"]
    SNAP --> POL["Protected-path and scope policy<br/>(Host)"]
    POL --> VER["Gate verification: metadata check, build, required checks, reproducer<br/>(verification jobs, Host-built plan, Host-observed results)"]
    VER --> JDG["Acceptance Judge<br/>(Host-launched provider job, enrolled profile, Host dossier)"]
    JDG --> ACC["Acceptance record<br/>(Host admission journal)"]
    ACC --> BLD["Production build x2, offline<br/>(build jobs), package and receipt (Host)"]
    BLD --> SW["G0 drain, fence, stop, preflight, commit<br/>(Host; Engine A drains, Engine B preflights)"]
    SW --> B["Successor Engine B<br/>(Host derives successor enrollment)"]
    VER -- fail --> REF["Refusal record<br/>(Host), Engine notified"]
    JDG -- reject --> REF
    POL -- protected change --> REF
```

| Step | Executes | Decides | Evidence created by |
|---|---|---|---|
| Incident, Parent Judge, Repair Run | Engine, provider jobs | Engine (product flow) | Engine Store (history, not authority) |
| Slot claim | Host | Host | admission journal |
| Developer patch | provider job in slot | nobody | the slot's Git repository (untrusted bytes) |
| Snapshot and identity | contained export job reads the slot repository; Host recomputes | Host | admission objects |
| Policy | Host | Host | admission journal |
| Verification | verification jobs | Host, from observed exit status and output | admission journal and objects |
| Acceptance Judge | provider job launched by the Host | Host, from the parsed enrolled-schema decision | admission journal, custody spool digest |
| Build | build jobs | Host (reproducibility and inventory) | build receipt |
| Switch | Host; A drains; B preflights on a copy | Host | `lifecycle.json`, `active.json`, `operations.ndjson` |

## 2. Engine requests to Admission

All on the Engine's pipe (03 §4, 05 §5). None of them carries authority: each is a request that the Host answers from its own state. Every request carries a `requestId`; a repeat with the same payload returns the recorded answer, a repeat with a different payload is a conflict.

| Request | Payload | Host checks before acting | Result |
|---|---|---|---|
| `Repair::EnrollmentStatus` | none | none | Effective enrollment summary: enrolled or not, admission open or the refusal reasons, remaining slots, current baseline identity |
| `Repair::ClaimSlot` | `repairRunId`, `parentRunId`, `incidentId` (labels only) | Installation enrolled; admission open (§2.1); a free slot exists; no other nonterminal admission | `slotId`, slot path; the slot grant is given to provider runs of this Repair only. Exhaustion refuses before any other effect (`p5_successor_workspace_exhausted`, existing code kept) |
| `Repair::SubmitCandidate` | `slotId`, `commit`, `reproducer` (test target and name) | Slot claimed and not already submitted for a different commit | `admissionId`; the Host starts §3-§5 asynchronously |
| `Repair::AdmissionStatus` | `admissionId` | none | Phase, refusal code, Judge question if any, build and switch progress |
| `Repair::ReportInvalidation` | `admissionId`, reason | none | The Host stops the admission. An Engine report can only narrow (refuse), never approve |

The run identifiers are correlation labels for the Engine's history and the UI. The Host does not derive authority from them. The authority of an admission comes from the slot claim (Host state) and the facts the Host establishes in §3-§5.

### 2.1 When admission is open

The Host opens admission only when all of these hold; otherwise every claim is refused with the reasons listed, as `decideProtectedSelfRepairAdmission` does today (`runtime/core/engine.mjs:279-322`), but evaluated by the Host on its own state:

- A root enrollment installed by the Owner exists in the Host's enrollment directory and validates.
- The selected Engine build has a Host-written build receipt or is the enrolled baseline itself.
- The installation enforces provider containment (no unconfined provider mode, open decision OD-1).
- The enrolled policy requires a causal reproducer (P5-CLOSURE §6 rule, kept).
- The toolchain, vendor set and Cargo.lock digests of the baseline match the installed toolchain and vendor directories.
- The Host advertises the P6 capability, and no nonterminal admission or switch exists.

### 2.2 What the P2 coordination keeps

The Parent incident, the Parent Judge's `request_repair`, the P2 approval, Parent suspension and resumption stay in the Engine (`runtime/core/linkedRepair.mjs`). The Host needs none of them as authority: a Repair the Engine started for no good reason still has to pass the Host's own verification and the Host-launched acceptance Judge. This removes the need for the Host to interpret the P2 records, which is the main reason the minimal Host can stay small.

The Owner keeps the ability to stop an in-flight update without trusting the Engine: an Owner Stop that reaches the gateway for a Run named in a nonterminal admission (Repair or Parent) is recorded by the Host as an invalidation before it is forwarded (05 §6). Under ADR-0010 §5, a committed Parent Stop before the switch blocks the switch; this rule keeps that, with the Host as the recorder.

## 3. Candidate source identity and protected-path policy

### 3.1 Snapshot and identity

1. The Host starts a contained export job (profile `DeszoVerify`, read grant on the slot repository, write grant on one scratch directory, no network) that runs the pinned Git executable to emit the raw objects reachable from `commit` (commit, trees, blobs) as a byte stream on its result pipe.
2. The Host parses only the Git object encoding and recomputes every object id itself, in the repository's object format, then checks that the tree reachable from `commit` is complete. Today the same recomputation exists in JS (`runtime/core/p6Reconstruction.mjs:31-72`, `buildGitTree`). A mismatch, an unknown object format or a missing object refuses.
3. The Host stores the snapshot as content-addressed objects in its admission directory. From here on, every job receives a read-only copy of these bytes, never the slot repository.

The Host never runs Git in its own process against a candidate-controlled repository, and it never uses the repository's configuration. The line-ending identity rules that the P5 CRLF tests established (`runtime/tests/p5-crlf-identity.test.mjs`) become test vectors for the recomputation (07 §4).

### 3.2 Protected-path and scope policy

The Host diffs the candidate tree against the baseline tree it holds (the source tree recorded with the active build). The policy file is Host-installed with the enrollment; its digest is in the root enrollment. P6 v1 rules:

| Rule | Paths (relative to the workspace root) | Reason |
|---|---|---|
| Allowed changes | `crates/deszo-engine/**`, `crates/deszo-workflow/**`, `crates/deszo-providers/**`, `crates/deszo-git/**`, `crates/deszo-store/src/**`, and `tests/` of those crates | Repairable crates (02 §5) |
| Refused: trusted crates | `crates/deszo-protocol/**`, `crates/deszo-host/**`, `crates/deszo-mcp/**`, `src-tauri/**`, `src/**` (UI), `crates/deszo-testkit/**`, `xtask/**` | Host, Shell, UI, protocol and tools are maintainer releases (ADR-0010 §3, kept) |
| Refused: build inputs | every `Cargo.toml`, `Cargo.lock`, `vendor/**`, `rust-toolchain*`, `.cargo/**`, any `build.rs` (new or changed) | No dependency, feature, profile, toolchain or build-script change in P6 v1 |
| Refused: data format | `crates/deszo-store/migrations/**` | No migration in P6 v1 (ADR-0010 §3, kept) |
| Refused: required checks | the test files named by the enrolled policy's required checks | A candidate cannot weaken the checks that judge it |
| Refused: tree shape | symbolic links, submodules, modes other than regular file, executable file and directory; non-UTF-8 names; names that collide case-insensitively; Windows reserved names; trailing dots or spaces; paths over the policy length; files or totals over the policy size bounds | Path identity must be unambiguous on every supported platform |
| Required | the reproducer is a new test under an allowed `tests/` path, named in the submission | Causal verification (§5) |

These rules replace the JS-specific `P6_PROTECTED_CONTROL_PATHS` list and the import-closure resolver (01 §3). The rules still matter in Rust, but for a different reason: the protected paths no longer contain the Engine's own authority (there is none to protect), they define what an autonomous change may affect.

## 4. Judge architecture for acceptance

### 4.1 The question

A Host cannot infer from a JSON object handed over by the Engine whether a model actually approved a fix. Three placements were considered:

| Option | What the Host would trust | Assessment |
|---|---|---|
| (a) The Engine runs the Judge; the Host validates provenance afterwards | The Engine's account of which invocation produced which output | Rejected: the Engine constructs both the invocation and the record. Nothing the Engine writes can prove the model's output |
| (b) The Engine keeps the Judge node; the Host owns the acceptance invocation and its result channel | Its own invocation construction, its own custody capture, its own parse | **Selected** |
| (c) The whole Judge workflow moves to the Host | Everything | Rejected: duplicates the workflow Judge (1,283 lines today), its attention, evidence and question model, inside the trusted base |

### 4.2 Selected: Host-owned acceptance invocation

- The Repair workflow keeps its mandatory Judge node. The node's acceptance mode does not build a provider invocation in the Engine. When the scheduler reaches it, the Engine asks `Repair::AdmissionStatus` and waits; the Host runs the acceptance invocation once verification has passed.
- The Host builds the invocation from the **enrolled Judge profile** (provider, model, effort, prompt template digest, output schema) and a **Host-built dossier**: the candidate diff from the Host snapshot, the policy result, the required check outcomes and output excerpts, the reproducer outcome on baseline and candidate, and the Engine-supplied incident narrative, labeled as unverified Engine input.
- The Host launches it through its own custody into `DeszoProvider`, captures stdout and stderr into its spool (the existing custody spool, `lifecycle-host/src/custody.rs:1182-1190`), and parses the final structured decision with the enrolled schema. The admitted decision kinds are `accept_repair`, `reject_repair`, `request_evidence` and `request_human_input`; anything else, or no parseable final decision, is a rejection.
- The acceptance record binds the invocation manifest digest, the executable identity (custody allowlist digest), the dossier digest, the spool digest, the parsed decision and the time.
- The Engine receives the decision through `AdmissionStatus` and applies it to its Repair Run as the Judge node's outcome, so the workflow, the journal and the UI show the Judge decision as today.

### 4.3 Owner input stays with the Judge

- `request_human_input`: the Host records an acceptance question and returns it through `AdmissionStatus`. The Engine presents it through its existing Judge question model (`runtime/core/workflowJudge.mjs:1080`), so the Judge remains the only role that asks the Owner.
- The Owner's answer arrives at the gateway on the existing answer route (`POST /api/v2/judge-questions/{id}/answers`). For a question that belongs to an admission, the gateway records the authenticated answer in the admission journal before forwarding it (05 §6). The next acceptance invocation receives it in the dossier. The Engine cannot invent an Owner answer to an acceptance question.
- `request_evidence`: the Host can expand the dossier only from its own records (more check output, more of the diff), bounded by the enrolled budget. Evidence from the Engine is not accepted for acceptance.

### 4.4 Limits

The Host proves that the enrolled Judge ran on the Host's dossier and returned this decision. It does not prove the judgement is right, and a model can be steered by content in the dossier (03 §5, A5). This is the same semantic limit as today (P6 final security review S5-7). The bound on the damage is 03 §7: an accepted wrong candidate gains only the Engine's contained authority.

## 5. Gate verification

The verification plan is built by the Host from the enrolled policy. The Engine supplies only the submission.

| Step | Job | Command shape | Pass condition |
|---|---|---|---|
| Metadata | `DeszoVerify` | `cargo metadata --offline --locked --format-version 1` on the candidate snapshot | Workspace members, targets and build-script kinds equal the baseline's; lockfile digest equal |
| Build | `DeszoVerify` | `cargo build --offline --locked` with Host-set flags | Exit 0 |
| Required checks | `DeszoVerify`, one process per check | `cargo test --offline --locked -p <crate> --test <target> -- --exact <name>`, after a `--list` run proves the test exists | Exit 0 for each; every named test listed |
| Reproducer on baseline | `DeszoVerify` | baseline tree plus the reproducer file only | The reproducer test exists and **fails** |
| Reproducer on candidate | `DeszoVerify` | candidate tree | The reproducer test **passes** |

Rules:

- Each job is offline, has a fresh scratch and target directory, a Host-controlled environment (no inherited variables beyond an allowlist; `CARGO_HOME` points to a Host-provided configuration whose only source is the vendored directory), and the time, memory and process limits of the enrolled budget.
- Results are what the Host observes: process exit status from its own handle, and output captured on its own pipes. No job produces a receipt, and nothing from inside the job is trusted as a summary. Today the verifier child reports a JUnit stream that the Engine turns into a receipt (`runtime/verification/p5Verifier.mjs`, `runtime/core/p5Gate.mjs:1140`); that pattern is not carried over.
- A dependency-artifact cache may speed up jobs only if it is produced by a job that compiles the vendored dependency set with no candidate code, and only copied read-only into later jobs. A target directory is never shared between candidate jobs.

## 6. Cargo build pipeline

### 6.1 Inputs and pinning

| Input | Policy |
|---|---|
| Workspace structure | 02 §5; the member list is part of the baseline metadata digest |
| `Cargo.lock` | Committed, protected, `--locked` everywhere; its digest is in the baseline and the receipt |
| Dependencies | Vendored with `cargo vendor`; per-crate checksums verified by Cargo; the vendor set is Host-installed per lock digest, read-only to jobs |
| Registry and Git dependencies | None at build time: source replacement to the vendored directory, `net.offline = true`; a candidate cannot add a source because `.cargo/` and `Cargo.toml` are protected |
| Toolchain | Pinned version in `rust-toolchain.toml` (protected); installed under `toolchain/<id>` with a Host-recorded file digest manifest, verified before each job like the custody tool identity (`custody.rs:174`) |
| Target | `x86_64-pc-windows-msvc` today. The MSVC linker and Windows SDK libraries are external inputs that must join the toolchain identity, or the Engine uses a self-contained target. Open decision OD-8 |
| Build profile | One release profile: fixed `opt-level`, `lto`, `codegen-units`, `panic`, `strip`, `debug = 0`; no PDB in the package |
| Flags | Set by the Host only: `--remap-path-prefix` for the workspace, `CARGO_HOME`, vendor and toolchain paths; `/Brepro` for the MSVC linker; no candidate-controlled `RUSTFLAGS` |
| Engine identity | `engineBuildId` derived by the Host from the receipt digest; embedded through a Host-set environment variable read at compile time, not from candidate source |

### 6.2 Reproducibility

Cargo builds are not automatically byte-for-byte reproducible. Paths, linker timestamps and debug information are the usual sources of difference. The P6 requirement to build twice and compare (ADR-0010 §10) is kept:

- Two production builds run in separate fresh directories with different absolute paths, each in its own build job.
- The Host compares the digests of every package file. Any difference refuses the admission.
- Whether this holds on Windows MSVC with the flags in §6.1 is prerequisite PR-4. If path independence cannot be achieved, the fallback is two sequential builds at the same canonical path, which still detects nondeterminism but not path leakage; choosing it is an explicit Owner decision recorded in the receipt (OD-8).

### 6.3 Build-time risks and their containment

Cargo runs code during builds. Build isolation is designed separately from runtime Engine isolation because the code is different: a build job runs the candidate's macros and any build scripts in the dependency graph before the Engine exists.

| Risk | Control in P6 v1 |
|---|---|
| `build.rs` in a repairable crate | Refused by policy (§3.2); vendored dependency build scripts are fixed by the protected lockfile and run only inside build jobs |
| Procedural macros | Only from vendored dependencies (fixed); they run inside the build job |
| Build-time environment (`env!`, `option_env!`) | The job environment is Host-built; the candidate cannot set variables |
| Compiler and linker invocation | Flags from the Host; `.cargo/config.toml` and `Cargo.toml` protected; linker and SDK identity pinned (OD-8) |
| `#[link]` and native libraries | Only libraries present in granted toolchain and SDK directories can be linked; the result is an Engine that runs contained |
| `include_bytes!` and similar | Can read only granted directories (snapshot, toolchain, vendor) |
| Dynamic library loading at run time | Inside the contained Engine; it does not cross the boundary, and the package contains only `deszo-engine.exe` and `build.json` |
| External tools from build scripts | Inside the job: offline, no Host grant, children contained |
| Outputs outside the workspace | Denied by containment; the Host collects only the named output file from the job's output directory |

## 7. Build receipt, stage and switch

```mermaid
flowchart LR
    SNAP[("Host snapshot<br/>accepted tree")] --> J1["Build job 1<br/>dir X, offline"]
    SNAP --> J2["Build job 2<br/>dir Y, offline"]
    TC[("Pinned toolchain<br/>vendor set, Cargo.lock")] --> J1
    TC --> J2
    J1 -- "output bytes" --> CMP{"Host: digests equal?"}
    J2 -- "output bytes" --> CMP
    CMP -- "no" --> REF["Refused"]
    CMP -- "yes" --> PKG["Host assembles package<br/>writes build.json, computes digests"]
    PKG --> RCPT[("BuildReceipt/2<br/>admission journal")]
    RCPT --> STG["Host-internal stage<br/>(existing package verification)"]
    STG --> G0["G0 drain, fence, preflight, commit"]
```

The build jobs only produce bytes. Every identity in the receipt is computed by the Host from inputs it supplied and outputs it collected.

1. After acceptance the Host runs the two production builds (§6.2) and assembles the package in its staging directory. The Host, not the build job, writes `build.json` (02 §6) and computes every digest.
2. The Host writes `BuildReceipt/2` to the admission journal: admission and acceptance record ids, candidate commit, tree and object format, policy digest, toolchain, vendor and lockfile digests, flags, both build output digests, the package digest, the `build.json` digest and the target Shell binding. It replaces `P6BuildReceipt/1` (ADR-0010 §7), which the Engine wrote into its own Store.
3. The Host stages the package with the existing package verification (`engine_switch.rs:246`, `:277`). The difference is the caller: staging is a Host-internal call made by Admission. It is no longer a command on any channel.
4. The Host asks Engine A to drain (`Lifecycle::DrainRequest`). A pauses dispatch, settles its work with its existing Run recovery and custody terminal evidence, and answers `DrainAck` with its view of active custody jobs. The Host independently requires zero active custody jobs for A's lineage, fences new launches, stops A and proves the tree ended. This is the G0 sequence (ADR-0010 §5) with A's final switch request replaced by its drain acknowledgement. If A never drains, the switch holds: that is an availability loss, not an authority gain.
5. The Host re-checks that the admission is still valid (no invalidation recorded, §2.2), guards the production Store, copies it, starts B in maintenance mode with a grant on the copy only, receives B's preflight result on B's own pipe, commits `active.json`, releases the guards and lets the same B process continue. Pre-commit fallback and the no-post-commit-rollback rule are unchanged.

## 8. Successor enrollment and A → B → C

```mermaid
sequenceDiagram
    participant O as Owner (once)
    participant H as Host + Admission
    participant A as Engine A
    participant B as Engine B
    participant C as Engine C
    O->>H: install root enrollment, policy, Judge profile, slot pool (N+1 slots)
    A->>H: ClaimSlot (slot 1), SubmitCandidate (commit b)
    H->>H: identity, policy, verification, acceptance Judge, build x2, receipt
    H->>A: DrainRequest
    A->>H: DrainAck
    H->>H: fence, stop A, preflight B on copy, commit active.json
    H->>H: successor enrollment: baseline = tree b, package = B
    H->>B: start (normal), activation receipt
    B->>H: EnrollmentStatus (open, slots 2..N+1 free)
    B->>H: ClaimSlot (slot 2), SubmitCandidate (commit c)
    H->>H: same Admission against baseline b
    H->>B: DrainRequest
    B->>H: DrainAck
    H->>H: commit C, successor enrollment: baseline = tree c
    H->>C: start (normal)
```

- The root enrollment is installed once and never rewritten. The Host derives each successor enrollment at commit: the baseline tree and package advance to the accepted candidate; the policy, Judge profile, scope, budgets, repository identity, publication references and slot pool are copied from the root. This is ADR-0010 §9's continuation rule with the Host as its only reader and writer. The Engine-side continuation chain reader (`runtime/core/p6Continuation.mjs`) is no longer needed.
- Slots are single-use and claims are permanent, as today (P5-08). A chain of N Repairs needs N+1 slots, because the successor of the last release still needs one (existing result, kept). Exhaustion refuses at `ClaimSlot`, before any build, staging or switch.
- Each successor can repair itself because nothing in the Engine binary is needed to admit its successor: Admission is in the Host, and the successor only needs to run the same Repair workflow and submit.
- No Owner action is required between the root enrollment and any later activation. No Git push is required: the Host's snapshot is the source of record; the Owner-requested branch publication (`runtime/core/p5GitCandidate.mjs`, the only `push`) remains optional.

## 9. Admission journal and recovery

Phases: `claimed` → `submitted` → `snapshot_verified` → `policy_passed` → `verifying` → `verified` → `judging` → `accepted` → `building` → `built` → then the G0 phases → `committed` → `verified`. Terminal refusals: `refused`, `rejected`, `invalidated`, `abandoned`.

- The journal is append-only, one record per transition, with content-addressed objects for snapshots, dossiers, spools and outputs, in the Host's admission directory (05 §3).
- On Host restart, `verifying`, `judging` and `building` become `abandoned`: partial job output is never trusted. The Engine may submit the same commit again; the slot claim stays, and the retry counts against the enrolled attempt budget.
- From `built` onward, the G0 reconciliation decides (`active.json` is the commit authority).

## 10. Mapping from the current P5/P6 records

| Current record (Engine Store) | Target record | Writer |
|---|---|---|
| `ProtectedSelfRepairEnrollment` file `profile/p5/enrollment.json` | `RootEnrollment/1` in the Host enrollment directory | Owner installs once; Host validates |
| Candidate manifest, verification inputs | `AdmissionRecord/1` and snapshot objects | Host |
| `ProtectedSelfRepairVerificationReceipt` built in the Engine | `VerificationRecord/1` | Host, from observed results |
| Judge decision artifact, `P5Acceptance` | `AcceptanceRecord/1` | Host |
| `ProtectedSelfRepairHandoff/1`, P2 outcome, retention | Engine history only; the Host does not read them | Engine |
| `P6Operation/1`, admission rows in `command_receipts` | The admission journal plus the existing `lifecycle.json` operation | Host |
| `P6BuildReceipt/1` | `BuildReceipt/2` | Host |
| P6 continuation receipts and successor profile | `SuccessorEnrollment/1` | Host |

The Engine keeps `self_repair.*` journal events for its own history and the UI projection, each carrying the Host record id it reflects. They are history, not evidence.
