# 06. Migration plan

## 1. Principles

- Incremental, with a testable result and an explicit compatibility boundary at every stage.
- Vertical slices measured against recorded behavior, not file-by-file translation of JavaScript.
- The Node Engine is not deleted until its replacement is verified (M10).
- The security boundary is built before the Rust Engine takes ordinary work: the Host's gateway, pipe transport, containment and Admission do not depend on Engine parity, and the Engine must be developed against the final channel from its first slice.
- No configuration that ships to an installation mixes a Node Engine with the new Host authority model (§4).
- The final state has no JavaScript backend: the Tauri WebView UI is the only JS/TS runtime.

## 2. Stages and dependencies

The brief's order (domain, Store, execution, Engine, P5, P6, packaging, removal) was revised in two places: feasibility prerequisites come first, because a failed containment result changes the design; and the Host restructuring moves ahead of the Rust Engine runtime, because the Engine must be written against the pipe protocol and the gateway, not against loopback and an Engine-held Owner Token.

```mermaid
flowchart LR
    M0["M0 Baseline and<br/>contract freeze"] --> M1["M1 Feasibility<br/>prerequisites PR-1..PR-7"]
    M0 --> M2["M2 deszo-protocol,<br/>canonical JSON, domain types"]
    M2 --> M3["M3 deszo-store<br/>read path, then write path"]
    M1 --> M4["M4 Host restructuring<br/>gateway, pipes, sandbox,<br/>custody scoping"]
    M2 --> M4
    M3 --> M5["M5 Execution primitives<br/>scheduler, attempts,<br/>providers, recovery"]
    M4 --> M5
    M5 --> M6["M6 Ordinary Engine parity<br/>API, workflows, Judge,<br/>P2, supervision"]
    M4 --> M7["M7 Host Admission (P5)<br/>identity, policy, verify,<br/>acceptance Judge, slots"]
    M1 --> M7
    M6 --> M8["M8 P6 build, switch,<br/>genuine A to B to C"]
    M7 --> M8
    M8 --> M9["M9 Packaging and cutover<br/>Shell, deszo-mcp, installer"]
    M9 --> M10["M10 Node backend removal"]
```

| Stage | Content | Depends on | Exit criterion |
|---|---|---|---|
| M0 | Freeze the behavioral baseline: API route inventory (`routeInventory`, `runtime/runner.mjs:515-526`), the 34 schemas, recorded provider streams from the fixture CLIs, journals of reference workflows, golden canonical-JSON vectors, a copy of a real profile, the contract map of 07 §2 | none | Baseline archive with digests; every contract family in 07 §2 has at least one recorded scenario |
| M1 | Feasibility prerequisites PR-1 to PR-7 ([09](09-open-decisions.md)) as isolated spikes with evidence files; no product code | M0 | Each prerequisite passed, or failed with its Owner decision recorded |
| M2 | `deszo-protocol` (frames, message kinds, canonical JSON, protected record kinds) and the domain types the Engine and Store share | M0 | Canonical bytes equal the JS output for every golden vector and every object of the profile copy |
| M3 | `deszo-store`: open, migrate (same SQL files), read every table; then the write path with transactions, objects, receipts | M2 | Rust reader produces the same projections as Node for the profile copy; a Node Engine opens a Rust-written Store without migration (proves rollback compatibility, §5) |
| M4 | Host maintainer change: gateway with Owner Token, Shell connection over a pipe, direct Engine spawn into Job and containment, explicit handle lists for every spawn, typed pipe transport, custody principal scoping, removal of `engine.stage`, `engine.switch`, `custody.attach` and `lifecycle.activate_candidate` from every child-reachable channel | M1 (PR-1, PR-5), M2 | Host integration tests against a skeleton Rust Engine; refusal tests of 07 §5 pass |
| M5 | Scheduler, Run capture and pinning, attempts, custody client, provider adapters and parsers, recovery, Stop and cancel | M3, M4 | Differential runs of the recorded fixture scenarios produce equivalent journals (07 §3) |
| M6 | All ordinary API routes, drafts and publications, Loop/Map/Task, review Gate, context packages, supervision, incidents, audit bundles, workflow Judge with Owner questions, P2 linked Repair client, branch delivery, SSE | M5 | Every row of the compatibility matrix (§3) marked done with its proof |
| M7 | Admission: root enrollment, slot pool, snapshot identity, path policy, verification jobs, acceptance Judge invocation, admission journal | M1 (PR-2, PR-3, PR-6), M4 | Admission accepts a fixture candidate and refuses each negative of 07 §5 |
| M8 | Production build jobs, reproducibility, `BuildReceipt/2`, Host-internal stage and switch trigger, successor enrollment, genuine A → B → C and exhaustion | M6, M7, PR-4 | 07 §6 genuine E2E passes from frozen artifacts |
| M9 | Shell retargeted to the gateway, `deszo-mcp`, `xtask` release packaging, cutover tooling (§5) | M8 | Packaged installation passes the full Rust regression and a cutover rehearsal on a profile copy |
| M10 | Remove the Node runtime, `runtime/`, `mcp/*.mjs`, the bundled Node, esbuild bundling, JS-specific P5 mechanisms, the legacy Control Host code | M9 | No JS outside `src/` and frontend build tooling; full regression green |

M5-M6 and M7 can proceed in parallel once M4 exists: Admission tests use fixture candidates and a skeleton Engine, and the Engine's Repair client tests use a fake Admission.

## 3. Compatibility matrix

| Subsystem | Old implementation | Rust replacement | Phase | Compatibility proof |
|---|---|---|---|---|
| Canonical JSON and hashing | `canonical.mjs` | `deszo-protocol::canonical` | M2 | Golden vectors; re-hash of all profile objects |
| SQLite Store | `store.mjs`, `migrations.mjs`, `m1`-`m22` | `deszo-store` | M3 | Same migration digests; projection equality; Node reads Rust-written Store |
| Workflow validation and planning | `validate.mjs`, `planning.mjs` | `deszo-workflow` | M5 | `docs/fixtures` contract cases; differential `validateWorkflow` responses |
| Drafts, publications, Run pinning | `engine.mjs:2019-2157`, `captureRun` | `deszo-engine` | M6 | Differential API v4 lifecycle; immutability refusals |
| Workflow scheduler | `engine.mjs` `pump`, `pumpRun`, `readiness` | `deszo-engine::scheduler` | M5 | Differential journals for reference workflows |
| Loop, Map, Task, review Gate | `mapRuntime.mjs`, `taskRuntime.mjs`, `gate.mjs` | `deszo-workflow` + scheduler | M6 | Recorded scenarios from loops, map, managed-task and revisions tests |
| Provider adapters | `adapters.mjs`, `transport.mjs`, `antigravityJudgeAdapter.mjs` | `deszo-providers` | M5 | Parser tests on recorded native streams; invocation argument equality |
| Custody | `custody.mjs` (Engine) + `custody.rs` (Host) | Engine client + Host module with principal scoping | M4, M5 | Existing Rust custody tests; custody E2E scenarios re-run |
| Judge | `workflowJudge.mjs` | `deszo-engine::judge` (ordinary); Host acceptance invocation | M6, M7 | Judge policy, runtime and scenario recordings; acceptance decision parse tests |
| P2 linked Repair | `linkedRepair.mjs` | `deszo-engine::repair` | M6 | Parent-repair coordination scenarios |
| P5 Gate | `p5Gate.mjs`, `p5Verifier.mjs` | Host Admission verification jobs | M7 | Gate negatives re-expressed (07 §5) |
| P5 enrollment, slots, alias checks | `protectedSelfRepair.mjs`, `workspaceIsolation.mjs`, `linkedRepair.mjs` slot functions | Host enrollment and slot pool; Engine keeps ordinary-run workspace reservation checks | M7 | Workspace pool, alias and reserved-run scenarios |
| P6 Builder and Consumer | `p6Builder.mjs`, `p6Consumer.mjs`, `p6Reconstruction.mjs`, `p6Scope.mjs` | Host Admission build and policy | M7, M8 | Reproducibility test; scope refusals; genuine E2E |
| P6 continuation | `p6Continuation.mjs`, `p6Successor.mjs` | Host successor enrollment | M8 | Successor identity cases re-expressed against the Host |
| G0 switch | `engine_switch.rs`, `store_guard.rs` | Kept; trigger changed | M4, M8 | Existing G0 tests re-pointed to the Host-internal trigger |
| API | `runner.mjs` | Host gateway + `deszo-engine::api` | M4, M6 | Route inventory equality; differential responses |
| Owner Token | `runner.mjs:68-79`, `:228-248` | Host gateway | M4 | Rotation, UI refresh and MCP reconnection tests |
| MCP bridge | `mcp/*.mjs` | `deszo-mcp` | M9 | Bridge tool contract tests |
| Shell supervisor and launch shim | `src-tauri/src/main.rs`, `supervisor.rs`, `bin/launch_shim.rs` | Host spawn and custody | M4 | Job containment and Stop proof tests moved to the Host |
| Runtime lock | `runtime/lock.mjs` | Host single-Engine rule + Engine lock file | M3, M4 | Runner-lock scenarios re-expressed |
| Test fault seams | `testFaultPolicy.mjs`, `testEngineProbe.mjs` | Cargo feature `test-seams`, refused in release manifests | M4 | Release manifest refusal test |
| Legacy Local Control Host | `runtime/host/*.mjs`, `native/*.cs` | None (retire, OD-5) | M10 | Archive of its database; autonomy routes answer unavailable |
| ADR-0007 Judge attention | `judgeAttention.mjs` | None (retire with OD-5) | M10 | Documented removal; workflow-native Judge unaffected |
| Build and release scripts | `scripts/*.mjs` | `xtask` | M9 | Release manifest equality for unchanged inputs |

No subsystem disappears without a row here.

## 4. Coexistence and its restrictions

During M2-M9 the Node Engine remains the shipped runtime. Its security posture is the one recorded in ADR-0011: the P6 release is blocked. The restrictions:

- No Node configuration with P6 activation is released: the ADR-0011 release block stays in force until the Rust cutover. This is already the release state, so the restriction removes nothing in use.
- The restructured Host (M4) runs only with Rust Engine builds and only in development and test profiles until M9. It never spawns a Node Engine: the Node Engine depends on loopback transport and on holding the Owner Token, both of which the new Host removes.
- No profile is used by both a Node Engine and a Rust Engine at the same time. The Host's single-Engine rule and the Engine lock enforce one writer.
- Development and differential tests run the two Engines against separate copies of the same profile, never against one live Store.

## 5. Cutover and rollback

Cutover is a maintainer release, not a P6 operation:

1. Preconditions: no nonterminal P6 operation; no active custody jobs; the profile's Runs settled under the existing Stop and recovery rules.
2. The release installs the new Host, Shell, `deszo-mcp`, toolchain, vendor set and the first Rust Engine build. The Store is backed up by the existing pre-migration backup rule (no migration is applied).
3. The Host moves the Owner Token and descriptor into its gateway directory, imports slot claims (05 §4), and archives the legacy Control Host database if present.
4. The Owner installs the root enrollment for the Rust baseline once (OD-2). This is a one-time installation event, not a per-update approval.
5. The Host starts the Rust Engine. The first Owner-visible check is the existing readiness and API health.

Rollback:

- Before the Rust Engine writes the Store: reselect the previous Node release, as a pre-commit fallback.
- After it writes: rollback to the Node release stays possible as long as the schema is unchanged and canonical bytes are identical, which M3's exit criterion proves (a Node Engine reads a Rust-written Store). Rust-era admission records stay in the Host store and are ignored by the Node release.
- Data is never restored from the backup automatically. Restoring it is an Owner action.

## 6. What M10 removes

`runtime/` (Engine, host-side JS, verification, tests after their Rust counterparts pass), `mcp/*.mjs`, `shared/*.mjs` as backend code (the UI imports `shared/effort.mjs`, `shared/replay.mjs` and `shared/task-config.mjs` directly, for example `src/model.ts:3-4` and `src/Replay.tsx:4`; those modules move into the frontend tree, and the Engine's effort policy becomes a Rust port checked against the same golden cases so the two cannot drift), `scripts/bundle-runtime.mjs` and the bundled Node, the esbuild-based P6 builder, the import-closure resolver, `P6_PROTECTED_CONTROL_PATHS`, the test-fault module policy, the C# native helpers of the legacy Control Host, and the launch shim. Historical ADRs and reviews are kept.
