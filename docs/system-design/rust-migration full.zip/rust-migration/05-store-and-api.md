# 05. Store, Host-Engine protocol, API and Owner Token

## 1. The ordinary Store today

- `runtime/core/store.mjs` opens `<profile>/store/state.sqlite` with `node:sqlite`, applies 22 migrations from `docs/storage/m1.sql`-`m22.sql` through the catalog in `runtime/core/migrations.mjs`, then sets `foreign_keys = ON`, `journal_mode = WAL` and `synchronous = FULL` (`store.mjs:41-71`).
- Each migration is one transaction together with its `schema_migrations` row, which records the SHA-256 of the script text. A store newer than the runtime is refused; an older one is backed up beside itself before migration (`store.mjs:47-54`).
- Immutable objects live under `store/objects/<first-two>/<sha256>`, staged under `store/staging/`, published by digest, then referenced from SQLite in one transaction ([STORAGE.md](../../STORAGE.md)).
- About 60 tables, among them `workflows`, `workflow_drafts`, `workflow_publications`, `runs`, `node_instances`, `attempts`, `journal_events`, `artifacts`, `artifact_references`, `command_receipts`, `run_links`, `judge_decisions`, `workflow_questions`, `incidents`, `control_grants`, `controller_sessions`, `attempt_custody`, `custody_workspace_holds`, `failure_outcomes`, `map_executions`, `managed_tasks`, `branch_deliveries`, `acceptance_records`.
- One writer: the Engine. `runtime/lock.mjs` keeps a second Engine out of the same root.
- Separately, the Host keeps `.deszo-host/active.json`, `profiles/<profile>/lifecycle.json`, `operations.ndjson` and custody records and spools. The legacy Local Control Host has its own database (`docs/storage/host-h1.sql`-`h5.sql`).

## 2. Rust Store access layer

| Concern | Design |
|---|---|
| Driver | `rusqlite` with the bundled SQLite build, version pinned in `Cargo.lock`. The on-disk format and WAL are compatible across SQLite 3.x; the exact versions on both sides are recorded by PR-7 |
| Location | Unchanged: `<profile>/store/state.sqlite`, `objects/`, `staging/`. History needs no copy or conversion |
| Migrations | The same 22 SQL files, embedded byte-for-byte with `include_str!`, so the recorded script digests in `schema_migrations` match. Same runner rules: one transaction per migration, backup before change, refuse a newer store, foreign-key check after each step |
| New migrations | Allowed only in maintainer releases. P6 v1 refuses any candidate that touches `crates/deszo-store/migrations/` (04 §3.2) |
| Transactions | One `BEGIN IMMEDIATE` per command commit covering events, projections and receipts, as today; journal events published to subscribers only after commit |
| Writer ownership | The Engine is the only writer. The Host never opens the ordinary Store, except the G0 guarded read-share handles and the disposable preflight copy (ADR-0010 §5, unchanged) |
| Single Engine | The Host refuses to spawn a second Engine for a profile; the Engine also holds an exclusive lock file in its Store directory, replacing `runner.lock.db` |
| Recovery | The current rules, ported: nonterminal Runs follow the existing interruption and continuation rules; custody holds keep workspaces held until reconciled |

### 2.1 Canonical JSON compatibility

Every artifact identity in history is the SHA-256 of bytes produced by `runtime/core/canonical.mjs`. The Rust implementation in `deszo-protocol` must produce identical bytes for every stored value:

- Object keys sorted by UTF-16 code units (`compareText`, `canonical.mjs:4`), not by Rust's default UTF-8 byte order; the two differ for characters above the Basic Multilingual Plane.
- Numbers serialized exactly as ECMAScript `Number.prototype.toString` does.
- Strict parsing: duplicate keys, lone surrogates, control characters and non-finite numbers rejected; a leading byte-order mark skipped (`parseStrictJson`, `canonical.mjs:12-60`).
- Existing artifacts are never rewritten. A Rust Engine that cannot reproduce an existing artifact's digest refuses to start on that profile rather than reinterpreting it.

PR-7 re-hashes every object of a real profile copy with the Rust implementation and compares with the stored digests.

## 3. Ordinary and protected state

**Decision:** two stores with two owners. The Engine owns the ordinary Store. The Host owns a separate, small protected store for enrollment, slots, admission and build receipts. Records that decide an installation are written only by the Host, from facts the Host established itself (04). No ordinary Store row is ever read as authority by the Host.

Alternatives considered:

| Approach | Why not selected |
|---|---|
| One shared Store with signed or keyed protected rows | It answers who wrote a row, not whether the decision behind it was made on real evidence; the Host would still have to make the decision itself, so the shared rows add a key-management problem and no authority. It also mixes two writers in one SQLite file, which the single-writer design avoids |
| A generic Host storage API that the Engine calls to write protected transitions | It turns the Host into a database service with Engine-chosen content; the Engine would still be the author of the evidence |
| A third process owning a trusted store (Option B) | Same records, one more process and protocol; see [08 §2](08-alternatives-and-tradeoffs.md) |

Protected store layout (Host-only directory, 02 §7):

```text
.deszo-host/profiles/<profile>/
  enrollment/root.json             RootEnrollment/1, installed once by the Owner
  enrollment/successors.ndjson     SuccessorEnrollment/1, appended by the Host at each commit
  admission/journal.ndjson         one record per admission transition (04 §9), fsync per record
  admission/objects/<sha256>       snapshots, dossiers, spools, check output, build outputs
  slots.json                       enrolled slot pool and permanent claims
  gateway/owner-token, gateway/descriptor.json
```

```mermaid
flowchart TB
    subgraph Engine["Engine (writer of the ordinary Store)"]
        R["Runs, journal, artifacts,<br/>workflows, grants"]
        HIST["self_repair.* history events<br/>(copies with Host record ids)"]
    end
    subgraph Host["Host (writer of the protected store)"]
        ENR["Root and successor enrollment"]
        SL["Slot pool and claims"]
        AJ["Admission journal and objects"]
        BR["Build receipts"]
        ACT["active.json, lifecycle.json, operations.ndjson"]
    end
    R -- "ClaimSlot, SubmitCandidate" --> SL
    R -- "SubmitCandidate" --> AJ
    AJ -- "accepted" --> BR
    BR -- "Host-internal trigger" --> ACT
    ACT -- "commit" --> ENR
    AJ -- "AdmissionStatus" --> HIST
```

Arrows into the Host are requests; the Host decides and writes. Arrows out of the Host are status the Engine records as history. No arrow lets the Host read an Engine row as evidence.

The format follows the Host's existing practice (`lifecycle.json`, `operations.ndjson`): JSON records and an append-only journal, no database. The journal is the authority; any index is derived and rebuildable.

How the separation is enforced: the directory is granted to no container profile (03 §1). Integrity of stored data comes from the operating system's access control; authenticity of a decision comes from the fact that only Host code creates these records. PR-1 must show the access denial for these exact paths.

## 4. Data preservation

| Data | Where it lives after migration | Compatibility proof |
|---|---|---|
| Published workflows, drafts, publication state | Engine Store, unchanged tables | Rust reads every row; publication snapshots re-hash to their stored digests (PR-7); differential API reads (07 §3) |
| Historical Runs, node instances, attempts | Engine Store, unchanged | Replay projections identical between Node and Rust readers |
| Run events (`journal_events`) | Engine Store, unchanged | Sequence contiguity and envelope digests verified on read |
| Artifacts and objects | Engine Store objects, unchanged | Full re-hash (PR-7) |
| Command receipts, idempotency | Engine Store, unchanged | Replay of recorded requests returns recorded responses |
| P5/P6 provenance from the Node era (handoffs, receipts, P6 operations) | Engine Store, read-only history | Shown in the UI as history; never read as evidence for a new admission (OD-2) |
| Host operation history | `.deszo-host/active.json`, `lifecycle.json`, `operations.ndjson`, unchanged formats, extended with new event kinds | Existing Host tests plus a reader test on the current files |
| Acceptance evidence | New Host protected store; Node-era acceptance is history only | Not applicable for old records; new records by construction |
| Workspace enrollments and slot claims | Host `slots.json`. At cutover, any slot that has a claim in the Engine Store is imported as consumed | Cutover check refuses if the imported pool has no free slot (OD-2) |
| Owner permissions and grants (`control_grants`, `controller_sessions`) | Engine Store, unchanged | Differential API tests of the grant routes |
| Owner Token | Moved from `profile/runtime/owner-token` to the Host gateway directory | Existing UI and MCP clients keep working with the same token value |
| Legacy Local Control Host database | Archived read-only; not opened by the new system (OD-5) | Archive digest recorded at cutover |

## 5. Host-Engine protocol

A small typed protocol in `deszo-protocol`, not a general IPC framework.

| Property | Design |
|---|---|
| Transport | One pair of anonymous pipes per Engine generation, inherited through an explicit handle list (03 §1). No loopback |
| Framing | Length-prefixed frames (u32 little-endian length, then canonical JSON), maximum frame 4 MiB; larger bodies and streams are chunked |
| Envelope | `{ v, id, kind, body }`; either side may initiate; responses carry the request `id` |
| Principal | The pipe. The Host knows which generation it spawned on that pipe. No capability string is exchanged |
| Session and generation | Every spawn creates fresh pipes and a new generation; `Ready` must name the generation the Host assigned |
| Replay | `id` unique per generation; requests that change Host state (`Repair::*`, `Custody::Reserve`, `Custody::Launch`) also carry a durable `requestId`, recorded by the Host for idempotent answers |
| Timeouts | Per kind: reads and status 10 s; custody calls 30 s; forwarded API requests by route bound; streams have no deadline but keepalives |
| Cancellation | `Cancel { id }` for forwarded requests whose client disconnected and for long reads |
| Errors | `{ code, message, retryable }` with stable codes (existing refusal codes such as `p5_workspace_claimed` kept) |
| Versioning | `protocolVersion` in `build.json` is checked before spawn and again in `Ready`; a mismatch refuses |

Message catalog:

| Direction | Kinds |
|---|---|
| Host to Engine | `Bootstrap` (generation, profile paths, maintenance spec if any), `Api::Request`, `Cancel`, `Lifecycle::DrainRequest`, `Lifecycle::Receipt`, `Lifecycle::Shutdown`, `Custody::Event` (state changes of the Engine's own records) |
| Engine to Host | `Ready`, `ReceiptAck`, `Status`, `RunningRelease`, `RunningInventory`, `Custody::{Reserve, Launch, Status, Read, Ack, Cancel, Stop}`, `Repair::{EnrollmentStatus, ClaimSlot, SubmitCandidate, AdmissionStatus, ReportInvalidation}`, `Lifecycle::{DrainAck, MaintenanceReady}`, `Api::{Response, Event, End}` |

The Engine-to-Host list is the complete list. Its counterpart today is the bridge's command set (`runtime/host/lifecycleBridge.mjs:80-108`) plus everything `custody(command)` could forward; the `engine.stage`, `engine.switch`, `custody.attach` and `lifecycle.activate_candidate` verbs have no successor on this channel (03 §4).

## 6. API gateway

The public API stays the same API (v2, v3 and v4 routes, 103 classified routes in `runtime/runner.mjs:227-452`). What changes is where the listener and the authentication live.

- **Listener.** The Host binds `127.0.0.1` on a port it records in the descriptor. It applies the current origin allowlist (`runner.mjs:27`), CORS headers, the 4 MiB request and response bounds (`runner.mjs:28-29`) and the bearer check (`identifyCaller`, `runner.mjs:195-202`).
- **Forwarding.** Every route not listed below is forwarded as `Api::Request { principal, method, path, query, allowlisted headers, body }`. Allowlisted headers are the ones the API uses today: `If-Match`, `If-None-Match`, `Last-Event-ID`, `Idempotency-Key`, `X-Deszo-Client-Label`, `X-Deszo-Controller-Token`. Route semantics, validation, ETags, quiescence (`runner.mjs:572-574`) and response bodies stay in the Engine.
- **Streams.** For SSE routes the gateway holds the HTTP response and writes the Engine's `Api::Event` frames; it sends keepalives itself.
- **Host-owned routes.**

| Route | Behavior |
|---|---|
| `POST /api/v2/owner-token/rotate` | The Host rotates the token, rewrites the descriptor and informs the Shell; the Engine is not involved (today `runner.mjs:228-248`) |
| `GET /api/v2/installation/source-release` | Answered by the Host from its own attestation |
| New read routes for enrollment and admission status | Owner reads of Host records, for the UI and audits |
| `POST /api/v2/judge-questions/{id}/answers` | For a question that belongs to an admission, the gateway records the authenticated answer in the admission journal, then forwards (04 §4.3). Other questions are forwarded unchanged |
| `POST /api/v2/runs/{id}/stop` and `stop-and-report` | For a Run named in a nonterminal admission, the gateway records an invalidation, then forwards (04 §2.2) |
| `/api/v2/autonomy/*` | Served today through the legacy Local Control Host; with OD-5 they answer `available: false`, as they already do when no Control Host is bound (`runner.mjs:249-252`) |

- **Retired with the legacy Control Host:** the `internal-host` routes and the `hostToken` credential (`runner.mjs:122`, `:416-430`), and the ADR-0007 Judge attention routes, which require Host authority from that Control Host (`runtime/core/judgeAttention.mjs:200-203`). The workflow-native Judge of ADR-0009 does not use them. This is open decision OD-5.

Gateway size is bounded by this list: authentication, framing, a route table of the Host-owned routes, and two recording hooks. It contains no Engine route semantics.

## 7. Owner Token model

| Question | Answer |
|---|---|
| Which process stores the Owner Token | The Host, in its gateway directory (02 §7). It creates the token on first start and moves the existing value from `profile/runtime/owner-token` at cutover, so existing clients keep working |
| Which process accepts Owner-authorized API operations | The Host gateway authenticates; the Engine executes the operation, receiving `principal: owner` on its pipe |
| How the Tauri UI authenticates | The Host passes the connection (port and token) to the Shell on the Shell's inherited pipe at spawn, and sends rotations on the same pipe. The Shell hands it to the window as `get_runner_connection` does today (`src-tauri/src/main.rs:434-441`) |
| How external API clients authenticate | Owner-run clients (the MCP bridge, scripts) read the descriptor from the Host gateway directory, which is readable by the user and granted to no container. Authority is unchanged: the Owner Token keeps full public API authority (ADR-0001 amendment). A scoped external-client token is optional (OD-6) |
| May the Engine see the Owner Token | No. It never receives it, and the descriptor is outside its grants |
| Publication and control-grant operations | Authenticated by the gateway, executed by the Engine as today. They change Engine-domain state only. The publications that matter for Self-Repair are pinned in the root enrollment by snapshot digest, so no Engine-side publication change alters what Admission requires |
| Judge responses | Ordinary Judge output is captured by Host custody and parsed by the Engine (Engine domain). The acceptance Judge is invoked, captured and parsed by the Host (04 §4) |
| Exclusion from repairable and provider contexts | Containment (03 §1), no Host secrets in any child environment (custody already strips lifecycle and custody variables, `lifecycle-host/src/custody.rs:1976` test), descriptor outside all grants |
| Owner API capability | Not reduced. No per-update approval is introduced |

The MCP bridge is ported to a Rust binary, `deszo-mcp`, with the same tools and the same descriptor-based connection (`mcp/runtime-client.mjs:12-39`). Managed provider runs keep excluding the bridge, as `runtime/core/managed-isolation.mjs` does today, and they cannot reach the loopback listener from their container anyway.
