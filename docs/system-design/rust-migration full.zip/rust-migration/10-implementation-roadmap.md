# 10. Implementation roadmap

Milestones follow the stages of [06](06-migration-plan.md). Each lists its deliverables and the acceptance criteria that close it. Evidence goes to `docs/reviews/evidence/<date>-rust-<milestone>/`, following the repository convention.

## R0 (M0): Baseline and contract freeze

- Deliverables: route inventory export; contract map of every test file (07 §2); recorded fixture scenarios and provider streams; canonical-JSON and Git-object golden vectors; a profile copy with its digest.
- Acceptance: every contract family has a recorded scenario; archive digests recorded; the Node suite passes on the frozen baseline that produced the recordings.

## R1 (M1): Feasibility prerequisites

- Deliverables: PR-1 to PR-7 evidence files and short reports ([09 §1](09-open-decisions.md#1-prerequisites)).
- Acceptance: each prerequisite passed, or failed with the Owner decision it triggers recorded; the design documents amended where a result changes them.

## R2 (M2-M3): Protocol and Store

- Deliverables: `deszo-protocol` (frames, message kinds, canonical JSON, record kinds); `deszo-store` read and write paths with the embedded migrations.
- Acceptance: golden vectors equal; profile-copy re-hash equal; Rust projections equal Node projections for the profile copy; a Node Engine opens a Rust-written Store without migration.

## R3 (M4): Host restructuring (maintainer release candidate, not shipped)

- Deliverables: gateway with the Owner Token and Host-owned routes; Shell connection over its pipe; direct Engine spawn into Job and container; `sandbox` module; explicit handle lists everywhere; typed Engine channel; custody principal scoping; removal of the privileged verbs from every child-reachable channel.
- Acceptance: Host integration tests against a skeleton Engine; the refusal tests of 07 §5 that concern the channel, the token and the grants pass; existing G0 tests pass with the Host-internal trigger driven by a test-only Admission stub compiled under `test-seams`.

## R4 (M5): Execution primitives

- Deliverables: scheduler, Run capture and pinning, attempts, custody client, provider adapters, recovery, Stop and cancel.
- Acceptance: differential journals equal (after the documented normalization) for the recorded scheduler, Loop, continuation and recovery scenarios.

## R5 (M6): Ordinary Engine parity

- Deliverables: all API routes; drafts and publications; Map, Task, review Gate, context packages, branch delivery; supervision, incidents, audit; workflow Judge and Owner questions; P2 Repair client against a fake Admission; SSE.
- Acceptance: every compatibility-matrix row (06 §3) marked done with its proof; route inventory equal; UI works unchanged against the gateway.

## R6 (M7): Host Admission

- Deliverables: root enrollment and its validation; slot pool; snapshot identity; protected-path policy; verification jobs; acceptance Judge invocation and Owner question recording; admission journal.
- Acceptance: a fixture candidate is accepted; each negative of 07 §5 is refused with its code; Host restart during `verifying`, `judging` and `building` yields `abandoned` and a clean resubmission.

## R7 (M8): P6 activation and genuine E2E

- Deliverables: production build jobs, reproducibility check, `BuildReceipt/2`, Host-internal stage and switch, drain protocol, successor enrollment.
- Acceptance: genuine A → B → C and exhaustion pass from frozen artifacts (07 §6) with no Owner approval after enrollment and no Git push; pre-commit fallback and hold paths pass their G0 tests.

## R8 (M9): Packaging and cutover

- Deliverables: `xtask` release; `deszo-mcp`; Shell retargeted; cutover and rollback tooling (06 §5).
- Acceptance: full Rust regression on one frozen snapshot; cutover rehearsal on a profile copy, including rollback to the Node release after Rust writes; independent read-only review of the release candidate with no open Critical or High finding.

## R9 (M10): Node backend removal

- Deliverables: removal list of 06 §6; documentation updates (ARCHITECTURE.md, STORAGE.md, ADR statuses).
- Acceptance: no JavaScript outside the frontend tree and its build tooling; full regression passes; the contract map shows a Rust test for every retired Node test or a recorded retirement decision.

## Gate rules for every milestone

- No milestone is closed on a claim that cannot be traced to an executed test or an evidence file.
- Earlier Node results never count as evidence for Rust behavior.
- A milestone that changes a contract amends the design document that owns it before code relies on the change.
